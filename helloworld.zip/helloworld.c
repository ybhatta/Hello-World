// Bhatta, Yubaraj	
// yxb4124
// 2019-02-04

#include <stdio.h>

int main( int argc, char *argv[] )
{
  printf("Hello, world!\n");
}
