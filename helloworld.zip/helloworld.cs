// Bhatta, Yubaraj
// yxb4124
// 2019-01-20

using System;
public class hmwk_01
{
  static public void Main( string[] args )
  {
     Console.WriteLine("Hello, world!");
  }
}

