// Bhatta, Yubaraj
// yxb4124
// 1001544124

public class hmwk_01 {
  public static void main( String[] args )
  {
    System.out.println("Hello, world!\n");
  }
}
