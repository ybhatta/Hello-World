// Bhatta, Yubaraj
// yxb4124
// 2019-02-04

#include <iostream>

using namespace std;

int main( int argc, char *argv[] )
{
  cout<<"Hello, world!\n";
}
